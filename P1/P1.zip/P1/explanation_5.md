# This Explanation is as part of The Project 1 => problem 5 

# Problem_5 Explanation documents

=>I decided to use a linked list data structure as this would help in joining each block in the chain.
=>The efficency of the algorithm is O(1), this is due to the while loop to go through each block in the chain.

=>Yes,Apend function is O(1)
=>The space complexity would O(n), depending on the number of nodes being created in the linked list.