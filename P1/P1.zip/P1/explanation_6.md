# This Explanation is as part of The Project 1 => problem 6
# Problem_6 Explanation documents

=> I decided to use a linked list data structure. Within the linked list I created a function to return the list in a python list, I then created the union and intersection functions. 
=> The efficency of the algorithm is O(n), this is due to the while loops and for loops that help create the linked list.
=> The space complexity would O(k+n), for both elements when creating the union and intersection.

=> here k and n are for linked lists 1 and 2 used in the program
