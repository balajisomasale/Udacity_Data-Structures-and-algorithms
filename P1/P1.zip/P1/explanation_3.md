# This Explanation is as part of The Project 1 => problem 2
# Problem_3 Explanation documents

=> I decide to use a binary tree data structure as this would help when creating the codes for each character. The recursive structure of the BST has a recursive algorithm. Searching in the tree has O(h) worst-case runtime complexity, where h is the height of the tree.
=> Since s binary search tree with n nodes has a minimum of O(log n) levels, it takes at least O(log n) comparisons to find a particular character. 

=> Talking about the space complexity of this algorithm would be O(k)(k being the number of nodes) for the tree and O(n) for the decoded text.