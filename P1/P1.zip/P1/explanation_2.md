# This Explanation is as part of The Project 1 => problem 2 
# Problem_2 Explanation documents
=> My Idea is to write a recursion algorithm as It is more efficient when filtering through the file paths.
=> Each file path would need to be checked until there were no more.
=> The efficiency of the algorithm is O(n) as it needs to check each files before moving to the next level of the path. 

=> Talking about the space complexity will depend on weather the algorithm finds a file with the required suffix, so I would say the space complexity is O(n).