# This Explanation is as part of The Project 1 => problem 1 
# Problem_1 : This is the basic problem on how/what to return the values inside the functions 

=> I have used the OrderedDict module as It is more efficient when we are searching for  the required keys 

=> All operations take O(1) time for the efficiency of the algorithm, 
   This includes the OrderedDict module operations like pop(item) and popitem(last=False) as there are also O(1).

=> Talking about the space complexity for this algorithm would be O(n),where n=capacity of cache
   Due to the limit of the cache. Once the limit is set, it wont change.