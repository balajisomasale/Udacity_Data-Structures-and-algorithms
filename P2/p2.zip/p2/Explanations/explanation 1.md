#This Explanation is as part of Project 2 => Problem 1
# Problem 1

=>Initially, I have attempted counting from 1 multiplying the iteration by itself until it reaches the target
  I thought it would be much better and EFFICIENT if i choose BST. 

Time Complexity: O(log(n))

Similar to searching a BST

Space Complexity: O(1)

Here, The Memory use is independent to the input. 
as Each loop run is INDEPENDENT