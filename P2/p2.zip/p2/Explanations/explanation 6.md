#This Explanation is as part of Project 2 => Problem 6
# Problem 6

=> My Code actually sets the initial min and max values as the FIRST value in the array. 
   It then ITERATES once through and follows accordingly

Time Complexity: O(n)

The array is iterated through once.

Space Complexity: O(1)

No additional memory is allocated.