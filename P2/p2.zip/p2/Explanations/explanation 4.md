#This Explanation is as part of Project 2 => Problem 4
# Problem 4

=>In order arrive at the solution, I kept a pointer to where the next 0 and 2 should be added. 
  Following this method the 1's sorted themselves automatically. The array was sorted in one pass.

Time Complexity: O(n)

The array is iterated through once.

Space Complexity: O(1)

Sorting was done in place.