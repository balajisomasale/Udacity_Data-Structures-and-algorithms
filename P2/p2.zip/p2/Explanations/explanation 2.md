#This Explanation is as part of Project 2 => Problem 2
# Problem 2

My rotated array is able to be search the required things using a Binary Search Algorithm. 
My first method involved finding the pivot seperately but I later realized this was not necessary and the element could be found in one pass.

Time Complexity: O(log n)

Binary Search

Space Complexity: O(1)

No additional space is used