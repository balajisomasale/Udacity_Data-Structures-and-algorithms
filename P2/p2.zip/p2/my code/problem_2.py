def rotated_array_search(input_list, number):
    """
    Find the index by searching in a rotated sorted array

    Args:
       input_list(array), number(int): Input array to search and the target
    Returns:
       int: Index or -1
    """
    #Using the Recursion function here : returning 0 and length of my list as start and end points
    return my_recursive_rotated_array(input_list,number,0,len(input_list) - 1)


def my_recursive_rotated_array(input_list, number, first_number, last_number):

    if first_number > last_number:
        return -1

    mid_index = (first_number + last_number) // 2
    mid_element = input_list[mid_index]

    if mid_element == number:
        return mid_index

    if input_list[first_number] <= mid_element:

        if mid_element > number and input_list[first_number] <= number:
            return my_recursive_rotated_array(input_list,
                                                  number,
                                                  first_number,
                                                  mid_index - 1)
        return my_recursive_rotated_array(input_list,
                                              number,
                                              mid_index + 1,
                                              last_number)

    if mid_element < number and input_list[last_number] >= number:
        return my_recursive_rotated_array(input_list,
                                              number,
                                              mid_index + 1,
                                              last_number)
    return my_recursive_rotated_array(input_list,
                                          number,
                                          first_number,
                                          mid_index - 1)


def linear_search(input_list, number):
    for index, element in enumerate(input_list):
        if element == number:
            return index
    return -1



def test_function(test_case):
    input_list = test_case[0]
    number = test_case[1]
    if linear_search(input_list, number) == rotated_array_search(input_list,
                                                                 number):
        print("Pass")
    else:
        print("Fail")

# Testing for the normal Test cases
test_function([[6, 7, 8, 9, 10, 1, 2, 3, 4], 6])
test_function([[6, 7, 8, 9, 10, 1, 2, 3, 4], 1])
test_function([[6, 7, 8, 1, 2, 3, 4], 8])
test_function([[6, 7, 8, 1, 2, 3, 4], 1])
test_function([[6, 7, 8, 1, 2, 3, 4], 10])

# Testing for the Empty array
test_function([[], 10])

# Testing for the array which has the single vaule
test_function([[1], 1])
test_function([[1], 0])

#Testing for the non rotated array
test_function([[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13], 3])
